import validateUser from '../src/validate_user'

test('Teste de retorno de usuário válido', () => {
    expect(3).toBe(3);
  });

test('Teste de retorno de usuário inválido', () => {
  expect(3).toBe(3);
});