import { Component, OnInit } from '@angular/core';
import { Consulta } from './consulta'
import { LoggingService } from '../logging.service';
import { HttpClient } from '@angular/common/http';
import { finalize } from 'rxjs/operators';

@Component({
  selector: 'app-server',
  templateUrl: './server.component.html',
  styleUrls: ['./server.component.css'],
  providers: [LoggingService, HttpClient]
})


export class ServerComponent implements OnInit {

  historico = []
  server_url = 'http://localhost:8080/status';
  mostrar_resposta = false
  consultaServer = {
    serverStatus: false,
    recolhido: false,
    recolhendo: false,
    error: '',
    resposta: ''
  }
  constructor(private logginService: LoggingService, private http: HttpClient) { }
  onDeleteConsulta (event) {
    this.logginService.addToLog('Deletado historico de consulta!', false);
    this.historico.splice(event.index, 1)
  }
  verificaServidor () {
    this.http.get(this.server_url).subscribe(response => {
      this.consultaServer.serverStatus = true
      console.log(response)
      this.consultaServer.resposta = JSON.stringify(response)
      this.historico.push(new Consulta(true, JSON.stringify(response)))
    }, error => {
      console.log(error)
      this.consultaServer.serverStatus = false
      this.consultaServer.error = JSON.stringify(error)
      this.historico.push(new Consulta(false, JSON.stringify(error)))
    })
  }
  ngOnInit() {
  }

}
